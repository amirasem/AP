package game.action.simple.check;

import game.interactable.AbstractInteractable;
import ui.UI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class CheckProperty extends AbstractInteractable {
    //TODO : bara gym batyad bara har kodom az health o energy ye list az  living property value type
    @Override
    public UI getUI() {
        return null;
    }
}
