package game.action.simple.picker;

import java.util.ArrayList;

/**
 * Created by jun on 5/19/17.
 * A simple LyAndroid Code.
 */
public class StorePicker extends AbstractPicker<GoodsAndPrices> {
    public StorePicker(String title, ArrayList<GoodsAndPrices> items) {
        super(title, items);
    }
}
