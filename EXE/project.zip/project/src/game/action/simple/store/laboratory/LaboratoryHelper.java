package game.action.simple.store.laboratory;

import game.entities.Entity;
import game.entities.type.api.EntityType;
import game.entities.type.instrument.farm.MachineType;
import game.interactable.Machine;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by AmirHosein on 7/10/2017.
 * ASAY
 */
public class LaboratoryHelper {
    private static LaboratoryHelper ourInstance = new LaboratoryHelper();

    public static LaboratoryHelper getInstance() {
        return ourInstance;
    }

    private LaboratoryHelper() {
    }
    // Singleton
    static ArrayList<Entity> getList() {
        java.util.ArrayList<Entity> list = new ArrayList<>();
        list.add(new Machine("Juicer" , MachineType.JUICER));
        list.add(new Machine("Spinning Wheel"  , MachineType.SPINNING_WHEEL));
        list.add(new Machine("Ultimate Cheese Maker" , MachineType.ULTIMATE_CHEESE_MAKER));
        return list;
    }
}
