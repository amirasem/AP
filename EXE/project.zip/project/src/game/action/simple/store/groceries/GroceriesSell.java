package game.action.simple.store.groceries;

import game.action.simple.store.Sell;
import game.entities.Entity;

import java.util.ArrayList;

/**
 * Created by jun on 5/19/17.
 * A simple LyAndroid Code.
 */
public class GroceriesSell extends Sell{
    public GroceriesSell(ArrayList<Entity> list) {
        super(list);
    }
}
