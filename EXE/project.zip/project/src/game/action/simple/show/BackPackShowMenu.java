package game.action.simple.show;

import game.interactable.AbstractInteractable;
import ui.UI;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class BackPackShowMenu extends AbstractInteractable {
    @Override
    public UI getUI() {
        return null;
    }
}
