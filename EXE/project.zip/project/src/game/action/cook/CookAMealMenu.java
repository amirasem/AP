package game.action.cook;

import game.interactable.AbstractInteractable;
import ui.UI;

/**
 * Created by ahay on 5/6/17.
 * <p>
 * GIBILI GIBILI
 */
public class CookAMealMenu  extends AbstractInteractable {
    @Override
    public UI getUI() {
        return null;
    }
}
