package game.interactable.field;

import game.interactable.AbstractInteractable;

/**
 * Created by jun on 5/19/17.
 * A simple LyAndroid Code.
 */
public abstract class AbstractCourt extends AbstractInteractable {
    public abstract String getName();
}
