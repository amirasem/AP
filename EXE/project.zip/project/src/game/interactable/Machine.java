package game.interactable;

import game.entities.Entity;
import game.entities.type.api.EntityType;
import ui.UI;
import ui.interactable.MachineUI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class Machine extends AbstractInteractable implements Entity {
    private final String name ;
    private final EntityType type ;

    public Machine(String name, EntityType type) {
        this.name = name;
        this.type = type;
    }

    @Override
    public UI getUI() {
        return new MachineUI(this);
    }

    @Override
    public EntityType getType() {
        return type;
    }

    @Override
    public String getStatus() {
        return type.getStatus();
    }
}
