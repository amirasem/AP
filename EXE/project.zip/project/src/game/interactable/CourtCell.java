package game.interactable;

import ui.UI;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class CourtCell extends AbstractInteractable {
    @Override
    public String getName() {
        return null;
    }

    @Override
    public UI getUI() {
        return null;
    }
}
