package game.environment;

/**
 * Created by ahay on 4/17/17.
 * GIBILI GIBILI
 */
public enum Season {
    SPRING, FALL, SUMMER, GREENHOUSE , WINTER;

    public String getName ()
    {
        return name();
    }
}
