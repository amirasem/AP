package game.places;

import ui.UI;
import ui.place.VillageUI;

/**
 * Created by ahay on 4/17/17.
 * GIBILI GIBILI
 */
public class Village extends AbstractPlace {
    private static Village ourInstance = new Village();

    public static Village getInstance() {
        return ourInstance;
    }

    private Village() {
        super(     );
    }

    public void goToMarket() {
        System.out.println("GoTo Market");
    }

    public void goToGym() {
        System.out.println("GoTo Gym");
    }

    public void goToRanch() {
        System.out.println("GoTo Ranch");
    }

    public void goToClinic() {
        System.out.println("GoTo Clinic");
    }

    public void goToLaboratory() {
        System.out.println("GoTo Laboratory");
    }

    public void goToCafe() {
        System.out.println("GoTo Cafe");
    }

    public void goToWorkshop() {
        System.out.println("GoTo Workshop");
    }


    @Override
    public UI getUI() {
        return new VillageUI();
    }

}
