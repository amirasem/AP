package game.places;

/**
 * Created by jun on 5/19/17.
 * A simple LyAndroid Code.
 */
public interface OnArrivalActionListener {
    void onEntrance();
}
