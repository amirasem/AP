package game.animals.properties;

import game.animals.properties.values.LivingPropertyValueType;

/**
 * Created by ahay on 4/19/17.
 * GIBILI GIBILI
 */
public interface Live {
    public void change(LivingPropertyType type, LivingPropertyValueType valueType, int value);
}
