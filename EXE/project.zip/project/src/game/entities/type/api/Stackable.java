package game.entities.type.api;

/**
 * Created by ahay on 4/19/17.
 * GIBILI GIBILI
 */
public interface Stackable extends EntityType {
    int getStackCount();
}
