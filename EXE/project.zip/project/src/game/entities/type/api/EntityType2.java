package game.entities.type.api;

/**
 * Created by AmirHosein on 7/4/2017.
 * ASAY
 */
public interface EntityType2 {
    public String getRealStatus();
}
