package game.entities.type.living.animal;

/**
 * Created by jun on 5/19/17.
 * A simple LyAndroid Code.
 */
public class Cow extends Animal {
    public Cow(String name) {
        super(name, AnimalType.COW);
    }
}
