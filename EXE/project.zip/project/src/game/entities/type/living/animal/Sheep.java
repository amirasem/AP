package game.entities.type.living.animal;

/**
 * Created by jun on 5/19/17.
 * A simple LyAndroid Code.
 */
public class Sheep extends Animal {
    public Sheep(String name) {
        super(name, AnimalType.SHEEP);
    }
}
