package game.exception;

/**
 * Created by Amir on 5/14/2017.
 * AHAY
 */
public class InvalidTargetException extends Exception {
    public InvalidTargetException() {
        super("Invalid Target!");
    }
}
