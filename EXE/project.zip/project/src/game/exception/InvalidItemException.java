package game.exception;

/**
 * Created by Amir on 5/14/2017.
 * AHAY
 */
public class InvalidItemException extends Exception {
    public InvalidItemException() {
        super("Invalid Item!");
    }
}
