package game.time;

/**
 * Created by Amir on 5/10/2017.
 * AHAY
 */
public interface TimeEventHandler {
    public void execute();
}
