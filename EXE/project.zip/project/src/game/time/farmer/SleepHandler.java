package game.time.farmer;

import game.mainchar.MainChar;
import game.time.TimeEventHandler;
import game.time.Watch;
import sun.security.pkcs11.wrapper.CK_SSL3_KEY_MAT_OUT;

import java.awt.event.WindowAdapter;

/**
 * Created by AmirHosein on 7/8/2017.
 * ASAY
 */
public class SleepHandler implements TimeEventHandler {
    @Override
    public void execute() {
        int counter = 0 ;
        System.out.println("Farmer go to sleep");
        Watch.getInstance().add(new Sleep());
        System.out.println("THE COUNTER IS  : " + Watch.getInstance().getCount());
        wakeup(Watch.getInstance().getCount());
        Watch.getInstance().run();

//        new WakeUp().execute();
    }
    public void wakeup (int counter)
    {
        if(counter>=2){
            System.out.println("ENTER HERE");
            Watch.getInstance().add(new WakeUp());
            Watch.getInstance().run();
        }

    }
    public int getCounter(int counter)
    {
        return counter++;
    }
}
