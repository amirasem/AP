package helper;

import java.util.Scanner;

/**
 * Created by ahay on 4/21/17.
 * GIBILI GIBILI
 */
public class SingleLineHelper {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) System.out.print(scanner.next() + " ");
    }
}
