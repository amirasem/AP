package ui.interactable.greenhouse;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class ChangeWheatherUI extends InteractableMenuUI {
    public ChangeWheatherUI(Interactable interactable) {
        super("", interactable);
    }
}
