package ui.interactable.greenhouse;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class RepairGreenhouseUI extends InteractableMenuUI {
    public RepairGreenhouseUI(Interactable interactable) {
        super("", interactable);
    }
}
