package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class CheckAnimalStatusForBuyUI extends InteractableMenuUI {
    public CheckAnimalStatusForBuyUI( Interactable interactable) {
        super("", interactable);
    }
}
