package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class FillUI  extends InteractableMenuUI {
    public FillUI(Interactable interactable) {
        super("Choose a Watering Can ", interactable);
    }
}
