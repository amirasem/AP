package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class RepairUI extends InteractableMenuUI {
    public RepairUI(Interactable interactable) {
        super("Choose an item want to repair:", interactable);
    }
}
