package ui.interactable.entities;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by ahay on 4/19/17.
 * GIBILI GIBILI
 */
public class BackpackUI extends InteractableMenuUI {
    public BackpackUI(Interactable interactable) {
        super("Choose an item: ", interactable);
    }


//    @Override
//    public void show() {
////        for()
//    }
//
//    @Override
//    public void run(int index) {
//
//    }
}
