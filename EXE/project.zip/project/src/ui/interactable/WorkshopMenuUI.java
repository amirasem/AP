package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by Amir on 5/11/2017.
 * AHAY
 */
public class WorkshopMenuUI extends InteractableMenuUI {
    public WorkshopMenuUI(Interactable interactable) {
        super("", interactable);
    }
}
