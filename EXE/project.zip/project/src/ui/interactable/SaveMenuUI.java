package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class SaveMenuUI extends InteractableMenuUI {
    public SaveMenuUI(Interactable interactable) {
        super("Choose or make new save file ", interactable);
    }
}
