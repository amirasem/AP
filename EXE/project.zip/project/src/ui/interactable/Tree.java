package ui.interactable;

import game.interactable.AbstractInteractable;
import ui.UI;

/**
 * Created by ahay on 5/3/17.
 * <p>
 * GIBILI GIBILI
 */
public class Tree extends AbstractInteractable {
    @Override
    public UI getUI() {
        return null;
    }
}
