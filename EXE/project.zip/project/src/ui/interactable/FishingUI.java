package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class FishingUI extends InteractableMenuUI {
    public FishingUI(Interactable interactable) {
        super("Choose a Fishing Rod from your inventory :", interactable);
    }
}
