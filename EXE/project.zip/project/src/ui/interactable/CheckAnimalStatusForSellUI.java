package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class CheckAnimalStatusForSellUI extends InteractableMenuUI {
    public CheckAnimalStatusForSellUI(Interactable interactable) {
        super("", interactable);
    }
}
