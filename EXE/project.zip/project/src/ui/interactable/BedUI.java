package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class BedUI extends InteractableMenuUI {
    public BedUI( Interactable interactable) {
        super("Bed ", interactable);
    }
}
