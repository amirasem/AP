package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class GiveFishUI  extends InteractableMenuUI {
    public GiveFishUI(Interactable interactable) {
        super("#Num Fish was caught. Effects ", interactable);
    }
}
