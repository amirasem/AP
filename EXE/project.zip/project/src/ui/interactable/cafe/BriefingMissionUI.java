package ui.interactable.cafe;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/10/2017.
 * AHAY
 */
public class BriefingMissionUI extends InteractableMenuUI {
    public BriefingMissionUI(Interactable interactable) {
        super("Briefing Mission", interactable);
    }
}
