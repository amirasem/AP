package ui.interactable.cafe;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/11/2017.
 * AHAY
 */
public class BuyMealUI extends InteractableMenuUI {
    public BuyMealUI(Interactable interactable) {
        super("Choose food want buy:", interactable);
    }
}
