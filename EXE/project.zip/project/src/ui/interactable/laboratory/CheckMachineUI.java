package ui.interactable.laboratory;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class CheckMachineUI extends InteractableMenuUI {
    public CheckMachineUI(Interactable interactable) {
        super("You can build these machines:", interactable);
    }
}
