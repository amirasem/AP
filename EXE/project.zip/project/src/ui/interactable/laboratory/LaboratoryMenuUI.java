package ui.interactable.laboratory;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class LaboratoryMenuUI extends InteractableMenuUI {
    public LaboratoryMenuUI(Interactable interactable) {
        super("", interactable);
    }
}
