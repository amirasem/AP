package ui.interactable.barn;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class BarnMenuUI extends InteractableMenuUI {
    public BarnMenuUI(Interactable interactable) {
        super("", interactable);
    }
}
