package ui.interactable;

import game.interactable.Butchery;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class ButcheryUIPlace extends InteractableMenuUI {


    public ButcheryUIPlace() {
        super("", Butchery.getInstance());
    }
}
