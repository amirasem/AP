package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class MachineUI extends InteractableMenuUI {
    public MachineUI(Interactable interactable) {
        super("", interactable);
    }
}
