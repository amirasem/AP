package ui.interactable;

import game.interactable.River;

/**
 * Created by ahay on 5/2/17.
 * <p>
 * GIBILI GIBILI
 */
public class RiverUI extends InteractableMenuUI {
    public RiverUI() {
        super("River :", River.getInstance());
    }
}
