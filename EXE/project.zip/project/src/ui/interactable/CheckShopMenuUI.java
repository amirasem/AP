package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/7/17.
 * <p>
 * GIBILI GIBILI
 */
public class CheckShopMenuUI extends InteractableMenuUI {
    public CheckShopMenuUI(Interactable interactable) {
        super("Check this Shop", interactable);
    }
}
