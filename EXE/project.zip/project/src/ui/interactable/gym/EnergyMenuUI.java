package ui.interactable.gym;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class EnergyMenuUI extends InteractableMenuUI {
    public EnergyMenuUI(Interactable interactable) {
        super("Choose what property value you want increase: ", interactable);
    }
}
