package ui.interactable.gym;

import game.interactable.Interactable;
import ui.interactable.InteractableMenuUI;

/**
 * Created by Amir on 5/12/2017.
 * AHAY
 */
public class GymMenuUI extends InteractableMenuUI {
    public GymMenuUI(Interactable interactable) {
        super("", interactable);
    }
}
