package ui.interactable;

import game.interactable.Interactable;

/**
 * Created by ahay on 5/8/17.
 * <p>
 * GIBILI GIBILI
 */
public class WoodsUI extends InteractableMenuUI {
    public WoodsUI(Interactable interactable) {
        super(" ", interactable);
    }
}
