package ui.interactable;

import game.interactable.Pond;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class PondUI extends InteractableMenuUI {

    public PondUI() {
        super("Pond", Pond.getInstance());
    }
}
