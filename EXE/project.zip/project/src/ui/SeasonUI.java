package ui;

import game.environment.Season;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class SeasonUI implements  UI{

    private final Season season ;

    public SeasonUI(Season season) {
        this.season = season;
    }

    @Override
    public void show() {

    }

    @Override
    public void run(int index) {

    }
}
