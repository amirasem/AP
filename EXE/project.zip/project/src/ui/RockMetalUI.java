package ui;

import game.entities.type.material.RockMetal;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class RockMetalUI implements UI {

    private final RockMetal rockMetal ;

    public RockMetalUI(RockMetal rockMetal) {
        this.rockMetal = rockMetal;
    }

    @Override
    public void show() {

    }

    @Override
    public void run(int index) {

    }
}
