package ui;

/**
 * Created by ahay on 4/19/17.
 * GIBILI GIBILI
 */
public interface UI {
    void show();

    void run(int index);
}
