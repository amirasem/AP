package ui.place;

import game.places.Farm;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class FarmUI extends PlaceUI {
    public FarmUI() {
        super(Farm.getInstance());
    }
}
