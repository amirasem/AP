package ui.place;

import game.places.Market;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class MarketUI extends PlaceUI {
    public MarketUI() {
        super(Market.getInstance());
    }
}
