package ui.place;

import game.places.*;
import game.places.store.*;
import ui.UI;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class VillageUI extends PlaceUI {

    public VillageUI() {
        super(Village.getInstance());
    }
}
