package ui.place;

import game.places.Jungle;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class JungleUI  extends PlaceUI {

    public JungleUI() {
        super(Jungle.getInstance());
    }
}
