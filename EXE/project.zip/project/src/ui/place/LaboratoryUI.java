package ui.place;

import game.places.Laboratory;
import game.places.Place;
import ui.UI;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class LaboratoryUI extends PlaceUI {

    public LaboratoryUI() {
        super(Laboratory.getInstance());
    }
}
