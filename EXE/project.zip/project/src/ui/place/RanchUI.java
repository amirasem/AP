package ui.place;

import game.places.store.Ranch;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class RanchUI extends PlaceUI{

    public RanchUI() {
        super(Ranch.getInstance());
    }
}
