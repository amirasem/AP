package ui.place;

import game.places.Gym;
import game.places.Place;
import ui.UI;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class GymUI extends PlaceUI {


    public GymUI() {
        super(Gym.getInstance());
    }
}
