package ui.place;

import game.places.Barn;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class BarnUI extends PlaceUI {
    public BarnUI() {
        super(Barn.getInstance());
    }
}
