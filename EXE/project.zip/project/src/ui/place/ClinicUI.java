package ui.place;

import game.places.store.Clinic;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class ClinicUI extends PlaceUI {


    public ClinicUI() {
        super(Clinic.getInstance());
    }
}
