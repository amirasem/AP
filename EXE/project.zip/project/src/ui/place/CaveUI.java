package ui.place;

import game.places.Cave;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class CaveUI extends PlaceUI {


    public CaveUI() {
        super(Cave.getInstance());
    }
}
