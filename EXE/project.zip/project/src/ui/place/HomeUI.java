package ui.place;

import game.places.Home;
import game.places.Place;
import ui.UI;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class HomeUI extends PlaceUI{

    public HomeUI() {
        super(Home.getInstance());
    }
}
