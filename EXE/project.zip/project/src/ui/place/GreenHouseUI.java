package ui.place;

import game.places.store.Greenhouse;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class GreenHouseUI extends PlaceUI {
    public GreenHouseUI() {
        super(Greenhouse.getInstance());
    }
}
