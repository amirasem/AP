package ui;

/**
 * Created by ahay on 5/1/17.
 * GIBILI GIBILI
 */
public interface UIObject {
    public UI getUI();
}
