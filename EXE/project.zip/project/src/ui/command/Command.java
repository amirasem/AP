package ui.command;

import game.action.simple.picker.BackPackPicker;
import game.exception.InvalidCommandException;
import game.exception.InvalidItemException;
import game.exception.InvalidTargetException;
import game.interactable.Interactable;
import game.main.Game;
import game.places.Place;
import ui.UIObject;

import java.util.ArrayList;

/**
 * Created by Amir on 5/14/2017.
 * AHAY
 */
public enum Command {
    BACKPACK("Backpack") {
        @Override
        void run() {
            new BackPackPicker().print();
        }
    }, BACK("Back") {
        @Override
        void run() {
            Game.getInstance().back();
        }
    },
    HELP("Help") {
        @Override
        void run() {
            String[] commands;
            commands = getPlaces(Game.getInstance().getPlace().getPlacesWeCanGo());
            printCommands(commands);
            String[] interactables;
            interactables = getInteractables(Game.getInstance().getPlace().getInteractableObjects());
            printInteractCommand(interactables);
        }
    },
    WHERE_AM_I("WhereAmI") {
        @Override
        void run() {
//            TODO: Not Working Exactly
            Game.getInstance().setUIObject(Game.getInstance().getPlace());
            UIObject ui = Game.getInstance().getUIObject();
            ui.getUI().show();
        }
    }, GO_TO("GoTo") {
        @Override
        void run()  {
            Game.getInstance().goTo(CommandLineHelper.getInstance().next());
//            TODO: Delete line below
//            WHERE_AM_I.run();
        }
    }, INSPECT("Inspect") {
        @Override
        void run()  {
            Game.getInstance().inspect(CommandLineHelper.getInstance().nextLine());
        }
    };
//    , GO_TO("GoTo") {
//        @Override
//        void run() throws InvalidItemException, InvalidTargetException, InvalidCommandException {
//            Game.getInstance().goTo(CommandLineHelper.getInstance().next());
////            TODO: Delete line below
////            WHERE_AM_I.run();
//        }
//    }, INSPECT("Inspect") {
//        @Override
//        void run() throws InvalidItemException, InvalidTargetException, InvalidCommandException {
//            Game.getInstance().goTo(CommandLineHelper.getInstance().nextLine());
//        }
//    };
    private final String command;

    Command(String command) {
        this.command = command;
    }

    abstract void run() ;

    public boolean equalsCommand(String command) {
        return this.command.equals(command);
    }

    public String[] getPlaces(ArrayList<Place> places) {
        String[] names = new String[places.size()];
        for (int i = 0; i < places.size(); i++) {
            names[i] = places.get(i).getClass().getSimpleName();
        }
        return names;
    }

    public void printCommands(String[] commands) {
        System.out.println("You can go these place with below commands : ");
        for (String command1 : commands) {
            System.out.println("GoTo " + command1);
        }
    }

    public String[] getInteractables(ArrayList<Interactable> interactables) {
        String[] result = new String[interactables.size()];
        for (int i = 0; i < interactables.size(); i++) {
            result[i] = interactables.get(i).getName();
        }
        return result;

    }

    public void printInteractCommand(String[] interactablesNames) {
        System.out.println("You can interact with below commands : ");
        for (String interactablesName : interactablesNames) {
            System.out.println("Inspect " + interactablesName);
        }
    }
}
