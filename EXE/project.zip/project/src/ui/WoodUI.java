package ui;

import game.entities.type.material.Wood;

/**
 * Created by ahay on 4/20/17.
 * GIBILI GIBILI
 */
public class WoodUI implements UI {

    private final Wood wood;

    public WoodUI(Wood wood) {
        this.wood = wood;
    }

    @Override
    public void show() {

    }

    @Override
    public void run(int index) {

    }
}
